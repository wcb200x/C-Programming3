﻿/*William Brown
 * CIS 199-75
 * Program 2
 * March 7, 2016
 * This program is designed to be used for user input into a GUI based form, that displays the earliest day
 * and time of registration for the desired individual. This form uses an if statement mostly in order to take the 
 * first letter of a last name along with total number of credit hours to display registration times for 
 * Summer/Fall 2016. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void calcRegisTimeBttn_Click(object sender, EventArgs e)
        // I will begin by declaring my variables
        {
            const double SOPHOMORE_CRDT_HRS = 30; // variable to hold Sophomore credit hour minimum
            const double JUNIOR_CRDT_HRS = 60; // variable to hold Junior credit hour minimum
            const double SENIOR_CRDT_HRS = 90; // varaible to hold Senior credit hour minimum
            double crdtHrs; // variable to hold user input for credit hours
            string lstNameLetter = lstNameTxtBx.Text; // variable to retrieve user input for Last Name
            string frshmn1 = "Tuesday, April 5"; // variable to hold freshman registration date 1
            string frshmn2 = "Wednesday, April 6"; // variable to hold freshman registration date 2
            string sophmre1 = "Friday, April 1"; // variable to hold sophomore registration date 1
            string sophmre2 = "Monday, April 4"; // variable to hold sophomore registration date 2
            string junior1 = "Thursday, March 31"; // variable to hold junior registration date 
            string senior1 = "Wednesday, March 30"; // variable to hold senior registration date
            string timeFrame1 = "8:30 AM"; // variable to hold first time frame
            string timeFrame2 = "10:00 AM"; // variable to hold second time frame
            string timeFrame3 = "11:30 AM"; // variable to hold third time frame
            string timeFrame4 = "2:00 PM"; // variable to hold fourth time frame
            string timeFrame5 = "4:00 PM"; // varaible to hold fifth time frame


            char first_letter; // variable to hold the first letter of the last name
            first_letter = char.ToUpper(lstNameLetter[0]); // retrieving first character of the word and making it uppercase

            if (double.TryParse(crdtHrsTxtBox.Text, out crdtHrs)) // crdtHrs begins holding user input after data validation for a double value (tryparse)
            {
                if (crdtHrs < SOPHOMORE_CRDT_HRS) // setting first if statement logic to account for the freshman class
                {
                    if (first_letter >= 'E' && first_letter <= 'Q') // determining whether the last name falls between a range of letters
                    {
                        gradeOutputLbl.Text = frshmn1; // assigning first freshman date for true
                    }
                    else
                    {
                        gradeOutputLbl.Text = frshmn2; // assigning second freshman date for false
                    }

                }
                else
                {
                    if (crdtHrs >= SOPHOMORE_CRDT_HRS) // setting logic to account for sophomore students
                    {
                        if (first_letter >= 'E' && first_letter <= 'Q') // determining whether the last name falls between a range of letters
                        {
                            gradeOutputLbl.Text = sophmre1; // assigning first sophomore date for true
                        }
                        else
                        {
                            gradeOutputLbl.Text = sophmre2; // assigning second sophomore date for true
                        }
                    }
                    if (crdtHrs >= JUNIOR_CRDT_HRS) // setting logic to account for junior students
                    {
                        gradeOutputLbl.Text = junior1; // assigning the junior registration date for true
                    }
                    if (crdtHrs >= SENIOR_CRDT_HRS) // setting logic to account for senior students
                    {
                        gradeOutputLbl.Text = senior1; // assigning the senior registration date for true
                    }
                }
                if (crdtHrs > 0) // if statement to begin setting times beginning with the freshman class
                {
                    if ((first_letter >= 'E' && first_letter <= 'F') || (first_letter == 'R' || first_letter == 'S')) // setting range of letters for the first time frame
                    {
                        timeOutputLbl.Text = timeFrame1; // assigning time frame 1 for true
                    }
                    else if ((first_letter >= 'G' && first_letter <= 'I') || (first_letter >= 'T' && first_letter <= 'V')) // setting range of letters for the second time frame
                    {
                        timeOutputLbl.Text = timeFrame2; //assigning frame 2 for true
                    }
                    else if ((first_letter >= 'W' && first_letter <= 'Z') || (first_letter >= 'J' && first_letter <= 'L')) // setting range of letters for the third time frame
                    {
                        timeOutputLbl.Text = timeFrame3; // assigning time frame 3 for true
                    }
                    else if ((first_letter >= 'A' && first_letter <= 'B') || (first_letter >= 'M' && first_letter <= 'O')) // setting range of letters for the fourth time frame
                    {
                        timeOutputLbl.Text = timeFrame4; // assigning time frame 4 for true
                    }
                    else if ((first_letter >= 'C' && first_letter <= 'D') || (first_letter >= 'P' && first_letter <= 'Q')) // setting range of letters for the fifth time frame
                    {
                        timeOutputLbl.Text = timeFrame5; // assigning time frame 5 for true
                    }
                }

                if (crdtHrs >= JUNIOR_CRDT_HRS) // if statement to begin setting times for the junior class
                {
                    if (first_letter >= 'E' && first_letter <= 'I') // setting range of letters for the first time frame 
                    {
                        timeOutputLbl.Text = timeFrame1; // assigning time frame 1 for true
                    }
                    else if (first_letter >= 'J' && first_letter <= 'O') // setting range of letters for the second time frame
                    {
                        timeOutputLbl.Text = timeFrame2; // assigning time frame 2 for true
                    }
                    else if (first_letter >= 'P' && first_letter <= 'S') // setting range of letters for the third time frame
                    {
                        timeOutputLbl.Text = timeFrame3; // assigning time frame 3 for true
                    }
                    else if (first_letter >= 'T' && first_letter <= 'Z') // setting range of letters for the fourth time frame 
                    {
                        timeOutputLbl.Text = timeFrame4; // assigning time frame 4 for true 
                    }
                    else if (first_letter >= 'A' && first_letter <= 'D') // setting range of letters for the fifth time frame
                    {
                        timeOutputLbl.Text = timeFrame5; // assigning time frame 5 for true
                    }
                }


            }
        }
        // I shall now include a clear button for the form
        private void clearButton_Click(object sender, EventArgs e)
        {
            gradeOutputLbl.Text = ""; // clears the output label that contains the day of earliest registration
            timeOutputLbl.Text = ""; // clears the output label the contains the time of earliest registration
            crdtHrsTxtBox.Text = ""; // clears the input text box for credit hours
            lstNameTxtBx.Text = ""; // clears the input text box for last name

        }
    }
}
//End of logic
       




