﻿namespace WindowsFormsApplication6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstNameTxtBx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.crdtHrsTxtBox = new System.Windows.Forms.TextBox();
            this.gradeOutputLbl = new System.Windows.Forms.Label();
            this.timeOutputLbl = new System.Windows.Forms.Label();
            this.calcRegisTimeBttn = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student\'s Last Name";
            // 
            // lstNameTxtBx
            // 
            this.lstNameTxtBx.Location = new System.Drawing.Point(123, 25);
            this.lstNameTxtBx.Name = "lstNameTxtBx";
            this.lstNameTxtBx.Size = new System.Drawing.Size(100, 20);
            this.lstNameTxtBx.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total Credit Hours";
            // 
            // crdtHrsTxtBox
            // 
            this.crdtHrsTxtBox.Location = new System.Drawing.Point(123, 59);
            this.crdtHrsTxtBox.Name = "crdtHrsTxtBox";
            this.crdtHrsTxtBox.Size = new System.Drawing.Size(100, 20);
            this.crdtHrsTxtBox.TabIndex = 3;
            // 
            // gradeOutputLbl
            // 
            this.gradeOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeOutputLbl.Location = new System.Drawing.Point(152, 116);
            this.gradeOutputLbl.Name = "gradeOutputLbl";
            this.gradeOutputLbl.Size = new System.Drawing.Size(133, 20);
            this.gradeOutputLbl.TabIndex = 4;
            // 
            // timeOutputLbl
            // 
            this.timeOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeOutputLbl.Location = new System.Drawing.Point(152, 172);
            this.timeOutputLbl.Name = "timeOutputLbl";
            this.timeOutputLbl.Size = new System.Drawing.Size(133, 20);
            this.timeOutputLbl.TabIndex = 5;
            // 
            // calcRegisTimeBttn
            // 
            this.calcRegisTimeBttn.Location = new System.Drawing.Point(23, 116);
            this.calcRegisTimeBttn.Name = "calcRegisTimeBttn";
            this.calcRegisTimeBttn.Size = new System.Drawing.Size(94, 50);
            this.calcRegisTimeBttn.TabIndex = 6;
            this.calcRegisTimeBttn.Text = "Calculate Registration Time";
            this.calcRegisTimeBttn.UseVisualStyleBackColor = true;
            this.calcRegisTimeBttn.Click += new System.EventHandler(this.calcRegisTimeBttn_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(23, 172);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(94, 50);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(151, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Day of Earliest Registration";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(151, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Time of Earliest Registration";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 252);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcRegisTimeBttn);
            this.Controls.Add(this.timeOutputLbl);
            this.Controls.Add(this.gradeOutputLbl);
            this.Controls.Add(this.crdtHrsTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstNameTxtBx);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Summer/Fall 2016 Registration Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lstNameTxtBx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox crdtHrsTxtBox;
        private System.Windows.Forms.Label gradeOutputLbl;
        private System.Windows.Forms.Label timeOutputLbl;
        private System.Windows.Forms.Button calcRegisTimeBttn;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

