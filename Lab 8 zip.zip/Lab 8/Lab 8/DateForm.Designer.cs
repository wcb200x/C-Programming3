﻿namespace Lab_8
{
    partial class DateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dateLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.mnthTxtBx = new System.Windows.Forms.TextBox();
            this.dayTxtBx = new System.Windows.Forms.TextBox();
            this.yearTxtBx = new System.Windows.Forms.TextBox();
            this.updteMnthBttn = new System.Windows.Forms.Button();
            this.updteDayBttn = new System.Windows.Forms.Button();
            this.updteYrBttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date:";
            // 
            // dateLbl
            // 
            this.dateLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dateLbl.Location = new System.Drawing.Point(101, 28);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(100, 14);
            this.dateLbl.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Month:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Day:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Year:";
            // 
            // mnthTxtBx
            // 
            this.mnthTxtBx.Location = new System.Drawing.Point(77, 75);
            this.mnthTxtBx.Name = "mnthTxtBx";
            this.mnthTxtBx.Size = new System.Drawing.Size(100, 20);
            this.mnthTxtBx.TabIndex = 5;
            // 
            // dayTxtBx
            // 
            this.dayTxtBx.Location = new System.Drawing.Point(77, 105);
            this.dayTxtBx.Name = "dayTxtBx";
            this.dayTxtBx.Size = new System.Drawing.Size(100, 20);
            this.dayTxtBx.TabIndex = 6;
            // 
            // yearTxtBx
            // 
            this.yearTxtBx.Location = new System.Drawing.Point(77, 135);
            this.yearTxtBx.Name = "yearTxtBx";
            this.yearTxtBx.Size = new System.Drawing.Size(100, 20);
            this.yearTxtBx.TabIndex = 7;
            // 
            // updteMnthBttn
            // 
            this.updteMnthBttn.Location = new System.Drawing.Point(197, 75);
            this.updteMnthBttn.Name = "updteMnthBttn";
            this.updteMnthBttn.Size = new System.Drawing.Size(100, 23);
            this.updteMnthBttn.TabIndex = 8;
            this.updteMnthBttn.Text = "Update Month";
            this.updteMnthBttn.UseVisualStyleBackColor = true;
            this.updteMnthBttn.Click += new System.EventHandler(this.updteMnthBttn_Click);
            // 
            // updteDayBttn
            // 
            this.updteDayBttn.Location = new System.Drawing.Point(197, 104);
            this.updteDayBttn.Name = "updteDayBttn";
            this.updteDayBttn.Size = new System.Drawing.Size(100, 23);
            this.updteDayBttn.TabIndex = 9;
            this.updteDayBttn.Text = "Update Day";
            this.updteDayBttn.UseVisualStyleBackColor = true;
            this.updteDayBttn.Click += new System.EventHandler(this.updteDayBttn_Click);
            // 
            // updteYrBttn
            // 
            this.updteYrBttn.Location = new System.Drawing.Point(197, 133);
            this.updteYrBttn.Name = "updteYrBttn";
            this.updteYrBttn.Size = new System.Drawing.Size(100, 23);
            this.updteYrBttn.TabIndex = 10;
            this.updteYrBttn.Text = "Update Year";
            this.updteYrBttn.UseVisualStyleBackColor = true;
            this.updteYrBttn.Click += new System.EventHandler(this.updteYrBttn_Click);
            // 
            // DateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 202);
            this.Controls.Add(this.updteYrBttn);
            this.Controls.Add(this.updteDayBttn);
            this.Controls.Add(this.updteMnthBttn);
            this.Controls.Add(this.yearTxtBx);
            this.Controls.Add(this.dayTxtBx);
            this.Controls.Add(this.mnthTxtBx);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateLbl);
            this.Controls.Add(this.label1);
            this.Name = "DateForm";
            this.Text = "Lab 8";
            this.Load += new System.EventHandler(this.DateForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox mnthTxtBx;
        private System.Windows.Forms.TextBox dayTxtBx;
        private System.Windows.Forms.TextBox yearTxtBx;
        private System.Windows.Forms.Button updteMnthBttn;
        private System.Windows.Forms.Button updteDayBttn;
        private System.Windows.Forms.Button updteYrBttn;
    }
}

