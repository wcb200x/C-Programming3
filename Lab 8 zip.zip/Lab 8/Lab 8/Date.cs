﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8
{
    public class Date
    {
        // backing fields
        private int _month;
        private int _year;
        private int _day;


        // Precondition: 01<= day < 32
        //               01<= month < 13
        //               00<= year
        // Postcondition: The date object has been intialized with the specified
        //                day, month and year.

        public Date(int d, int m, int y)
        {
            Month = m;
            Day = d;
            Year = y;
        }

        public int Year
        {
            //Precondition: none
            //Postcondition: the year has been returned 
            get
            {
                return _year;
            }
            // Precondition: 0 < value
            //Postcondition: the year has been set to a specified value
            set
            {
                if (value > 0)
                    _year = value;
                else
                    _year = 0;
            }
        }
        public int Day
        {
            //Precondition: none
            //Postcondition: the day has been returned 
            get
            {
                return _day;
            }
            //Precondition: 0 < value <= 31
            //Postcondition: the day has been set to a specified value
            set
            {
                if (value > 0 && value <= 31)
                    _day = value;
                else // when invalid set to default zero
                    _day = 0;
            }
        }

        public int Month
        {
            //Precondition: none
            //Postcondition: the month is returned 
            get
            {
                return _month;
            }
            //Precondition: 0 < value <= 12
            //Postcondition: the month has been set to a specified value
            set
            {
                if (value > 0 && value <= 12)
                    _month = value;
                else //when invalid set to default zero
                    _month = 0;
            }
        }

        //Precondition: none
        //Postcondition: a string is returned with the date in MM/DD/YYYY format
        public override string ToString()
        {
            string result;
            result = Month.ToString("D2") + "/" + Day.ToString("D2") + "/" + Year.ToString("D4"); // concatenates values to assign to build date string
            return result;
        }

         
    }
}

    
   
      





