﻿/*William Brown
 * Lab 8
 * 4/19/2016
 * This lab is designed to use an outside "business logic" designed class and incorporate it into a form design and display 
 * certain dates depending on user input. It displays the date in format MM/DD/YYYY.
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_8
{
    public partial class DateForm : Form
    {
        //Precondition: none
        //Postcondition: new Date objects are created depending on user input
        private Date date = new Date(1, 1, 2000);
    
        public DateForm()
        {
            InitializeComponent();
        }
        //Load event for the form to display default date 01/01/2000
             private void DateForm_Load(object sender, EventArgs e)
        {
            dateLbl.Text = date.ToString(); // setting dateLbl to 01/01/2000
        }

             private void updteMnthBttn_Click(object sender, EventArgs e)
             {
                 int mnthInput; //varaiable to hold month input

                 if (int.TryParse(mnthTxtBx.Text, out mnthInput)) // validation
                 {
                     //setting Month to user input and displaying in the forms label
                     date.Month = mnthInput; // setting mnthInput equal to Month in the Date class
                     dateLbl.Text = date.ToString();
                     mnthTxtBx.Clear();
                 }
                 else
                 {
                     MessageBox.Show("Invalid Month"); // if invalid data, display Invalid month 
                 }

                    

             }

             private void updteDayBttn_Click(object sender, EventArgs e)
             {
                 int dayInput; // variable to hold day input
                 if (int.TryParse(dayTxtBx.Text, out dayInput))
                 {
                     //setting Day to hold user input and displaying it in the forms label
                     date.Day = dayInput; // setting dayInput equal to Day in the Date class
                     dateLbl.Text = date.ToString();
                     dayTxtBx.Clear();
                 }
                 else
                 {
                     MessageBox.Show("Invalid Day"); // if invalid data, display Invalid Day
                 }

             }

             private void updteYrBttn_Click(object sender, EventArgs e)
             {
                 int yearInput; // variable to hold year input

                 if (int.TryParse(yearTxtBx.Text, out yearInput)) // validation
                 {
                     //setting Year to hold user input and displaying it in the forms label
                     date.Year = yearInput; // setting yearInput equal to Year in the Date class
                     dateLbl.Text = date.ToString();
                     yearTxtBx.Clear();
                 }
                 else
                 {
                     MessageBox.Show("Invalid Year"); // if invalid data, display Invalid Year
                 }
             }
             }
    }

