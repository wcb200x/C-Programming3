﻿/*William Brown
 * CIS 199-75
 * Program 1
 * 2/14/16
 * This program calculates the total square foot, the amount of paint used, how many hours of labor, 
 * how much the paints costs, how much the labor costs, and the total amount of labor based on user
 * generated input. Using several different calculations, the program runs to base its calculations 
 * off three inputs. 
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
          //I will begin naming variables and constants to use in the calculations of the program

            const double Square_Feet_Per_Gallon = 325; // this variable describes how many square feet per gallon constant
            const double Hours_Per_Gallon = 8; // this variable describes how many hours of labor per gallon constant
            const double Cost_Per_Hour_Labor = 10.50; // this variable describes how much per hour of labor constant
            double hoursOfLabor; // this variable is used to calculate total hours of labor in project
            double squareFeet; // this variable is used to bring in given values and find total square feet
            int numberOfCoats; // this variable describes how many coats of paint are to be used
            double totalGallonsOfPaint; // this variable describes total gallons of paint to be used 
            double totalCostOfPaint; // this variable describes the total cost of paint
            double cost_Per_Gallon; // this variable brings in input from the user on the price of paint
            double cost_Of_Labor; // this variable describes the calculation needed to determine total cost of labor
            double unroundedHoursOfLabor; // this variable describes the unrounded total amount of hours worked
            double total_cost; // this variable describes the total cost ensued from the project

           // I will begin bringing input in from user input

            //Variable used to bring in input by the user from the pricePerGallonTextbox
            cost_Per_Gallon = double.Parse(pricePerGallonTextbox.Text);

            //Variable used to bring in input by the user from the numOfCoatsTextbox
            numberOfCoats = int.Parse(numOfCoatsTextbox.Text);

        // I will begin calculations for each of my labels and adding information to them

            //Calculation for Total Hours of Labor
            squareFeet = (double.Parse(squareFeetTextbox.Text) * numberOfCoats); // this is a calculation of the total square footage being painted, bringing in input by the user and multiplying it by number of coats
            unroundedHoursOfLabor = ((squareFeet / Square_Feet_Per_Gallon) * Hours_Per_Gallon); // this is a calculation of how many hours it will take to finish the project 
            hoursOfLabor = Math.Round(unroundedHoursOfLabor,1); // this is rounding the total hours of labor to one decimal point
            totalHoursLabel.Text = hoursOfLabor.ToString("n1"); // this is putting the number calculated into the totalHoursLabel

            //Calculation for Total Square Foot Output
            squareFootTotalLabel.Text = squareFeet.ToString(""); // this is taking the calculated total square footage and putting it in the totalSquareFootTotalLabel
            
            //Calculation for Total Gallons of Paint
            totalGallonsOfPaint = squareFeet / Square_Feet_Per_Gallon; // this is taking total square feet divided by square feet per gallon to get total gallons of paint
            totalGallonsOfPaint = Math.Ceiling(totalGallonsOfPaint); // this is rounding the previous calculation up one integer number
            totalGallonsLabel.Text = totalGallonsOfPaint.ToString(""); // this takes the rounded calculation and places it into the totalGallonsLabel

            //Calculation for Total Cost of Paint
            totalCostOfPaint = totalGallonsOfPaint * cost_Per_Gallon; // this calculation take totalGallonsOfPaint times cost_Per_Gallon to get the total cost of paint
            totalCostOfPaintLabel.Text = totalCostOfPaint.ToString("c"); // this takes the totalCostOfPaint and puts it in the totalCostOfPaintLabel

            //Calculation for Total Cost of Labor
            cost_Of_Labor = unroundedHoursOfLabor * Cost_Per_Hour_Labor; // takes the unrounded hours of labor multiplied by cost of labor per hour to give you total cost of labor
            totalCostOfLaborLabel.Text = cost_Of_Labor.ToString("c"); // takes the calculation's sum and puts it inside the totalCostOfLaborLabel

            //Calculation for Total Cost
            total_cost = totalCostOfPaint + cost_Of_Labor; // calculation for total cost of paint plus total cost of labor
            totalCostLabel.Text = total_cost.ToString("c"); // takes the number and puts into the totalCostLabel




           



        }
    }
}
