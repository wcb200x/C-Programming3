﻿/* William Brown
 * Lab 3
 * CIS 199-75
 * 2/9/2016
 * This program takes different percentages and calculates the tip to add to the bill
 * depending on a high tip amount, medium tip amount, and low tip amount and calculates them 
 * together onto a form.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3_2_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateDiscountButton_Click(object sender, EventArgs e)
        {
           //Constant fields
            const double Lowest_Tip_Percentage = .15; //constant low percentage
            const double Medium_Tip_Percentage = .18; //constant mid percentage
            const double High_Tip_Percentage = .20; //constant high percentage

            double mealPrice; // meal's price
            double lowTipPrice; // calculation variable lowest percentage * meal price
            double medTipPrice; // calculation variable medium percentage * meal price
            double highTipPrice; // calculation variable highest percentage * meal price

            //Get the meal price from the textbox
            mealPrice = double.Parse(inputTextBox.Text);

            //Calculate lowest Tip Amount
            lowTipPrice = (Lowest_Tip_Percentage * mealPrice);

            //Calculate Medium Tip Amount
            medTipPrice = (Medium_Tip_Percentage * mealPrice);

            //Calculate High Tip Amount
            highTipPrice = (High_Tip_Percentage * mealPrice);

            //Display lowest tip amount in lowest tip label
            lowestTipLabel.Text = lowTipPrice.ToString("c");

            //Display medium tip amount in medium tip label
            mediumTipLabel.Text = medTipPrice.ToString("c");

            //Display high tip amount in high tip label
            highestTipLabel.Text = highTipPrice.ToString("c");



              



            

        }
    }
}
