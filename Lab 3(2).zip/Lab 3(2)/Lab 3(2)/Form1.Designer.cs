﻿namespace Lab_3_2_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.firstTipPercentageLabel = new System.Windows.Forms.Label();
            this.midTipPercentageLabel = new System.Windows.Forms.Label();
            this.highTipPercentageLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.lowestTipLabel = new System.Windows.Forms.Label();
            this.mediumTipLabel = new System.Windows.Forms.Label();
            this.highestTipLabel = new System.Windows.Forms.Label();
            this.calculateDiscountButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(90, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter price of meal: ";
            // 
            // firstTipPercentageLabel
            // 
            this.firstTipPercentageLabel.AutoSize = true;
            this.firstTipPercentageLabel.Location = new System.Drawing.Point(161, 110);
            this.firstTipPercentageLabel.Name = "firstTipPercentageLabel";
            this.firstTipPercentageLabel.Size = new System.Drawing.Size(27, 13);
            this.firstTipPercentageLabel.TabIndex = 1;
            this.firstTipPercentageLabel.Text = "15%";
            // 
            // midTipPercentageLabel
            // 
            this.midTipPercentageLabel.AutoSize = true;
            this.midTipPercentageLabel.Location = new System.Drawing.Point(161, 162);
            this.midTipPercentageLabel.Name = "midTipPercentageLabel";
            this.midTipPercentageLabel.Size = new System.Drawing.Size(27, 13);
            this.midTipPercentageLabel.TabIndex = 2;
            this.midTipPercentageLabel.Text = "18%";
            // 
            // highTipPercentageLabel
            // 
            this.highTipPercentageLabel.AutoSize = true;
            this.highTipPercentageLabel.Location = new System.Drawing.Point(161, 214);
            this.highTipPercentageLabel.Name = "highTipPercentageLabel";
            this.highTipPercentageLabel.Size = new System.Drawing.Size(27, 13);
            this.highTipPercentageLabel.TabIndex = 3;
            this.highTipPercentageLabel.Text = "20%";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(209, 58);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputTextBox.TabIndex = 4;
            // 
            // lowestTipLabel
            // 
            this.lowestTipLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowestTipLabel.Location = new System.Drawing.Point(209, 108);
            this.lowestTipLabel.Name = "lowestTipLabel";
            this.lowestTipLabel.Size = new System.Drawing.Size(100, 23);
            this.lowestTipLabel.TabIndex = 5;
            // 
            // mediumTipLabel
            // 
            this.mediumTipLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumTipLabel.Location = new System.Drawing.Point(209, 161);
            this.mediumTipLabel.Name = "mediumTipLabel";
            this.mediumTipLabel.Size = new System.Drawing.Size(100, 23);
            this.mediumTipLabel.TabIndex = 6;
            // 
            // highestTipLabel
            // 
            this.highestTipLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highestTipLabel.Location = new System.Drawing.Point(209, 214);
            this.highestTipLabel.Name = "highestTipLabel";
            this.highestTipLabel.Size = new System.Drawing.Size(100, 23);
            this.highestTipLabel.TabIndex = 7;
            // 
            // calculateDiscountButton
            // 
            this.calculateDiscountButton.Location = new System.Drawing.Point(171, 311);
            this.calculateDiscountButton.Name = "calculateDiscountButton";
            this.calculateDiscountButton.Size = new System.Drawing.Size(96, 33);
            this.calculateDiscountButton.TabIndex = 8;
            this.calculateDiscountButton.Text = "Calculate Tip";
            this.calculateDiscountButton.UseVisualStyleBackColor = true;
            this.calculateDiscountButton.Click += new System.EventHandler(this.calculateDiscountButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "$";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 380);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.calculateDiscountButton);
            this.Controls.Add(this.highestTipLabel);
            this.Controls.Add(this.mediumTipLabel);
            this.Controls.Add(this.lowestTipLabel);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.highTipPercentageLabel);
            this.Controls.Add(this.midTipPercentageLabel);
            this.Controls.Add(this.firstTipPercentageLabel);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tip Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label firstTipPercentageLabel;
        private System.Windows.Forms.Label midTipPercentageLabel;
        private System.Windows.Forms.Label highTipPercentageLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Label lowestTipLabel;
        private System.Windows.Forms.Label mediumTipLabel;
        private System.Windows.Forms.Label highestTipLabel;
        private System.Windows.Forms.Button calculateDiscountButton;
        private System.Windows.Forms.Label label2;
    }
}

