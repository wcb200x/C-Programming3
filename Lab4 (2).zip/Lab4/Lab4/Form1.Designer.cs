﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLabel = new System.Windows.Forms.Label();
            this.admLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.gpaTxtBox = new System.Windows.Forms.TextBox();
            this.admScoreTxtBox = new System.Windows.Forms.TextBox();
            this.testButton = new System.Windows.Forms.Button();
            this.successCntLabel = new System.Windows.Forms.Label();
            this.failCntLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaLabel
            // 
            this.gpaLabel.AutoSize = true;
            this.gpaLabel.Location = new System.Drawing.Point(102, 30);
            this.gpaLabel.Name = "gpaLabel";
            this.gpaLabel.Size = new System.Drawing.Size(60, 13);
            this.gpaLabel.TabIndex = 0;
            this.gpaLabel.Text = "GPA Score";
            // 
            // admLabel
            // 
            this.admLabel.Location = new System.Drawing.Point(102, 70);
            this.admLabel.Name = "admLabel";
            this.admLabel.Size = new System.Drawing.Size(60, 27);
            this.admLabel.TabIndex = 1;
            this.admLabel.Text = "Admission Score";
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(128, 145);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(100, 23);
            this.outputLabel.TabIndex = 2;
            // 
            // gpaTxtBox
            // 
            this.gpaTxtBox.Location = new System.Drawing.Point(186, 27);
            this.gpaTxtBox.Name = "gpaTxtBox";
            this.gpaTxtBox.Size = new System.Drawing.Size(100, 20);
            this.gpaTxtBox.TabIndex = 3;
            // 
            // admScoreTxtBox
            // 
            this.admScoreTxtBox.Location = new System.Drawing.Point(186, 67);
            this.admScoreTxtBox.Name = "admScoreTxtBox";
            this.admScoreTxtBox.Size = new System.Drawing.Size(100, 20);
            this.admScoreTxtBox.TabIndex = 4;
            // 
            // testButton
            // 
            this.testButton.Location = new System.Drawing.Point(141, 201);
            this.testButton.Name = "testButton";
            this.testButton.Size = new System.Drawing.Size(75, 35);
            this.testButton.TabIndex = 5;
            this.testButton.Text = "Admission Status";
            this.testButton.UseVisualStyleBackColor = true;
            this.testButton.Click += new System.EventHandler(this.testButton_Click);
            // 
            // successCntLabel
            // 
            this.successCntLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.successCntLabel.Location = new System.Drawing.Point(5, 112);
            this.successCntLabel.Name = "successCntLabel";
            this.successCntLabel.Size = new System.Drawing.Size(42, 22);
            this.successCntLabel.TabIndex = 6;
            // 
            // failCntLabel
            // 
            this.failCntLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.failCntLabel.Location = new System.Drawing.Point(55, 112);
            this.failCntLabel.Name = "failCntLabel";
            this.failCntLabel.Size = new System.Drawing.Size(42, 22);
            this.failCntLabel.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Accepted";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Rejected";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 261);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.failCntLabel);
            this.Controls.Add(this.successCntLabel);
            this.Controls.Add(this.testButton);
            this.Controls.Add(this.admScoreTxtBox);
            this.Controls.Add(this.gpaTxtBox);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.admLabel);
            this.Controls.Add(this.gpaLabel);
            this.Name = "Form1";
            this.Text = "Admission Status";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLabel;
        private System.Windows.Forms.Label admLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.TextBox gpaTxtBox;
        private System.Windows.Forms.TextBox admScoreTxtBox;
        private System.Windows.Forms.Button testButton;
        private System.Windows.Forms.Label successCntLabel;
        private System.Windows.Forms.Label failCntLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

