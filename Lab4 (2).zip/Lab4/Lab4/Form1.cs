﻿/* William Brown
 * Lab 4
 * 2/16/16
 * CIS 199-75
 * This lab is used as a Grade calculator of whether or not you would be accepted or rejected depending on your grade point average and your
 * admission score. It keeps a running total of how many applicants are accepted or rejected. It does this and displays the outputs into 
 * labels on the form*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    { // variables used for running total labels

        const int counterTick = 1; //used as a base number to add onto the running total 

        private int totalCount = 0; //the base number for the accepted running total

        private int totalCnt = 0; // the base number for the reject running total
   
        public Form1()
        {
            InitializeComponent();
        }

        private void testButton_Click(object sender, EventArgs e)
        { // variables to hold constants and local variables

            const double GPA_Score = 3.0; // constant to hold GPA score cutoff 
            const double High_Admission_Score = 80; // constant to hold the highest cutoff for admission score
            const double Low_Admission_Score = 60; // constant to hold the lowest cutoff for admission score
            double gpaInput; // variable to retrieve user input from the GPA textbox
            int admInput; //variable to retrieve user input from admission score textbox
                        

            //Get the information input from the textboxes by the Parse method

            gpaInput = double.Parse(gpaTxtBox.Text); // retrieves user input from the GPA textbox
            admInput = int.Parse(admScoreTxtBox.Text); // retrieves user input from the admission score textbox 

            //Determine whether the user qualifies by comparing GPA score
            if (gpaInput >= GPA_Score)
            {
                if (admInput >= Low_Admission_Score)
                {   //The user has a high enough combination of scores
                      outputLabel.Text = "Accepted"; // display Acccepted in the label
                      totalCount += counterTick; //total successes plus one 
                      successCntLabel.Text = totalCount.ToString(""); // running total input string for accepted
                }
            }
            else
            {  //The user does not have a high enough combination of scores
                   outputLabel.Text = "Reject"; //display reject in the label
                   totalCnt += counterTick; // total rejects plus one
                   failCntLabel.Text = totalCnt.ToString(""); // running total input string for reject

            }
            if (gpaInput < GPA_Score)
            {
                if (admInput >= High_Admission_Score)
                { //The user has a high enough score
                    outputLabel.Text = "Accepted"; //display accepted in the label
                    
                }
                else
                { // The user does not qualify
                    outputLabel.Text = "Reject"; // display reject in the label
                    
                    
                }
            }
            



               

        }
    }
}
