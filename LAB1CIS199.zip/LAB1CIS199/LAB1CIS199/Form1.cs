﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB1CIS199
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        //William Brown, CIS 199-75, 1/26/16
        //three buttons that show 1) my hobbies, 2) my favorite book series, and 3) my favorite movie. Each button follows the messagebox.show format and so when you click on the button when running the program it shows the text added after the show function in the message box. 
       
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Soccer, video games, and hanging out with friends");
                 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The Pendragon Series");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Into the Wild");
        }
    }
}
