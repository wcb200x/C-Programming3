﻿/*William Brown
 * Program 4
 * 4/24/2016
 * This program is designed to calculate the cost of shipping a package using different dimensions and the origin and 
 * destination zip codes. This program uses the business logic class GroundPackage to run and calculate user input from a form. 
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4
{
    public partial class ShippingForm : Form
    {
        List<GroundPackage> shippinglistBx = new List<GroundPackage>(); //new list using GroundPackage class
        int uoflZip = 40292; //uofl zip code referenced across class

        public ShippingForm()
        {
            InitializeComponent();
        }

        private void addToFormBttn_Click(object sender, EventArgs e)
        {
            int origin; //variable to hold origin zip code
            int destination; //variable to hold destination zip code
            double length; //variable to hold length 
            double width; //variable to hold width
            double height; //variable to hold height
            double weight; //variable to hold weight 

            //if statement using block validation to validate all information input and set them into specific variables
            if (int.TryParse(orginZipTxtBx.Text, out origin) && int.TryParse(destZipTxtBx.Text, out destination)
                && double.TryParse(lengthTxtBx.Text, out length) && double.TryParse(widthTxtBx.Text, out width) &&
                double.TryParse(heightTxtBx.Text, out height) && double.TryParse(weightTxtBx.Text, out weight))
            {
                //outing input into a new method
                GroundPackage newPack = new GroundPackage(origin, destination, length, width, height, weight);

               shippinglistBx.Add(newPack); 

               shippingListBx.Items.Add(newPack.CalcCost().ToString("C")); //adding the calculated cost to the Listbox on the form

                //Clearing each textbox 
                orginZipTxtBx.Clear();
                destZipTxtBx.Clear();
                lengthTxtBx.Clear();
                widthTxtBx.Clear();
                heightTxtBx.Clear();
                weightTxtBx.Clear();
            }
            else
            {
                MessageBox.Show("Enter a valid number for each field"); //if invalid data, display error message in MessageBox
            }

            }

        private void detailsBttn_Click(object sender, EventArgs e)
        {
            if (shippingListBx.SelectedIndex >= 0) //valiadation selectedindex >= 0
            {
                MessageBox.Show(shippinglistBx[shippingListBx.SelectedIndex].ToString()); // displaying detail output in a MessageBox
            }
            else
            {
                MessageBox.Show("Click an item on the list"); // display error message in MessageBox
            }

        }

        private void toUofLBttn_Click(object sender, EventArgs e)
        {
            if (shippingListBx.SelectedIndex >= 0) //validating selectedindex >= 0
            {
                int index = shippingListBx.SelectedIndex; // setting index equal to selected index in the ListBox
                shippinglistBx[index].DestinationZip = uoflZip; //setting destination zip code to the uofl zip code
                shippingListBx.Items[index] = shippinglistBx[index].CalcCost().ToString("C"); // calculating new cost based on uofl zip code
            }
            else
            {
                MessageBox.Show("Click an item on the list"); // display error message in MessageBox
            }
        }

        private void fromUofLBttn_Click(object sender, EventArgs e)
        {
            if(shippingListBx.SelectedIndex >= 0) // validation for selectedindex >= 0
            {
                int index = shippingListBx.SelectedIndex; // setting index equal to selectedindex
                shippinglistBx[index].OriginZip = uoflZip; // setting origin zip code to uofl zip code
                shippingListBx.Items[index] = shippinglistBx[index].CalcCost().ToString("C"); // calculating new cost based on uofl zip code
            }
            else
            {
                MessageBox.Show("Click on an item on the list"); // display error message
            }
        }

        }

        }
    

