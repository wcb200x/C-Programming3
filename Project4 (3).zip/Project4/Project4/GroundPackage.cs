﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    class GroundPackage
    {
        
        private int _originzipcode; 
        private int _destinationzipcode;
        private double _length;
        private double _width;
        private double _height;
        private double _weight;
        private double CONST_WEIGHT = .50;
        private double CONST_DIMENSION = .20;
        
        //Public class GroundPackage that holds 6 parameters
        public GroundPackage(int orzip, int destzip, double lngth, double wdth, double hght, double wght)
        {
            OriginZip = orzip; //setting OriginZip property
            DestinationZip = destzip; //setting DestinationZip property
            Length = lngth; //setting Length property
            Width = wdth; //setting Width property
            Height = hght; //setting Height property
            Weight = wght; //setting Weight property
        }

       
        public int OriginZip
        {
            //Precondition: none
            //Postcondition: the origin zip code is returned
            get
            {
                return _originzipcode;
            }
            //Precondition: 00000=< value =< 99999
            //              Length == 5
            //Postcondition: the origin zip code has been set to a specified value
            set
            {
                if (value >= 00000 && value <= 99999 && value.ToString().Length == 5) //setting 
                    _originzipcode = value;
               
            }
        }
        public int DestinationZip
        {
            
            //Precondition: none
            //Postcondition: the destination zip code is returned
            get
            {
                return _destinationzipcode;
            }
            //Precondition: 00000 =< value =< 99999
            //              Length == 5
            //Postcondition: the destination zip code has been set to a specific value
            set
            {
                if (value >= 00000 && value <= 99999 && value.ToString().Length == 5)
                    _destinationzipcode = value;
                
            }
        }
        public double Length
        {
            //Precondition: none
            //Postcondition: the length is returned 
            get
            {
                return _length;
            }
            //Precondition: value > 0
            //Postcondition: the length has been set to a specific value
            set
            {
                if (value > 0)
                    _length = value;
                else
                    _length = 0;
            }
        }
        public double Width
        {
            // Precondition: none
            //Postcondition: the width is returned
            get
            {
                return _width;
            }
            //Precondition: value > 0
            //Postcondition: the width has been set to a specified value
            set
            {
                if(value > 0)
                    _width = value;
                else
                    _width = 0;
            }
        }
        public double Height
        {
            //Precondition: none
            //Postcondition: the height is returned
            get
            {
                return _height;
            }
            set
                //Precondition: value > 0 
                //Postcondition: the height has been set to a specified value
            {
                if(value > 0)
                    _height = value;
                else
                    _height = 0;
            }
        }
        public double Weight
        {
            //Precondition: none
            //Postcondition: the weight is returned
            get
            {
                return _weight;
            }
            //Precondition: value > 0
            //Postcondition: the weight has been set to a specified value
            
            set
            {
                if (value > 0)
                    _weight = value;
                else
                    _weight = 0;
            }
        }
        //ZoneDistance property with a get 
        public int ZoneDistance
        {
            //Precondition: none
            //Postcondition: returns absolute value of destinationzip minus originzip divided by 10000
            get
            {
                return Math.Abs((DestinationZip - OriginZip)/10000); 
            }
        }
        //CalcCost method with no parameters
        public double CalcCost()
        {
            return CONST_DIMENSION * (Length + Width + Height) + CONST_WEIGHT * (ZoneDistance + 1) * Weight; // returns CalcCost 
        }
        public override string ToString()
        {
            // returns strings followed by each property information then used System.Environment.NewLine
            // to display them one after another vertically. 
            return "The Package Length is" + " " + Length + System.Environment.NewLine + "The Package Width is" + " " +  Width + System.Environment.NewLine +
                "The Package Height is" + " " + Height + System.Environment.NewLine + "The Package Weight is" + " " + Weight + System.Environment.NewLine +
                "The Origin Zip Code is" + " " + OriginZip.ToString("D5") + System.Environment.NewLine + "The Destination Zipcode is" +
                " " + DestinationZip.ToString("D5");
        }

        }


    }

