﻿/* William Brown
 * CIS 199-75
 * Lab 6
 * This lab requires us to design a console application that displays different star patterns on the screen by using loops. */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    class Program
    {
        static void Main(string[] args)
            //I will declare one constant variable
        { const int MAX_ROWS = 10; // declaring MAX_ROWS as constant variable 10

            for (int row = 1; row <= MAX_ROWS; row++) // setting parameters for first row pattern
            {
                for (int star = 1; star <= row; star++) // setting parameters for first star pattern
                    Console.Write("*"); // displaying stars in output
                Console.WriteLine(); // displaying the result in the console application
            }


            Console.WriteLine(); // adding a space in between patterns

            for (int row = 1; row <= MAX_ROWS; row++) // setting parameters for second row pattern
            {
                for (int star = 10; star >= row; star--) // setting parameters for second row pattern
                    Console.Write("*"); // displaying stars in output
                Console.WriteLine(); // displaying result in the console application
            }

            Console.WriteLine(); // adding a space in between patterns

            for (int row = 0; row <= MAX_ROWS; row++) // setting parameters for the third row pattern
            {
                for (int space = row; space > 0; space--) // setting spacing for the star pattern
                {
                    Console.Write(" "); // displaying a blank space for output
                }
                for (int star = MAX_ROWS - row; star >= 0; star--) // setting parameters for third star pattern
                {
                    Console.Write("*"); // displaying stars for output
                }
                Console.WriteLine(); // displaying result in the console application
            }

            Console.WriteLine(); // adding space between patterns

            for (int row = 2; row <= (MAX_ROWS + 1); row++) // setting parameters for fourth row pattern
            {
                for (int space = MAX_ROWS; space >= row; space--) // setting spacing for the star pattern
                {
                    Console.Write(" "); // displaying a blank space for output
                }
                for (int star = row; star > 1; star--) // setting parameters for fourth star pattern
                {
                    Console.Write("*"); // displaying stars for output
                }
                    Console.WriteLine(); // displaying result in the console application
                }
            }
        }
    }

