﻿// William Brown
//CIS 199-75
//February 2, 2016
//Lab 2
/*This program takes input from text boxes assigned to different parts of a persons name
 * and the prefixes associated with that person and displays the name depending on
 * different formats that each button has been assigned to display.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void formatOneButton_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 1 button
            output = preferredNameTextbox.Text + " " +
                firstNameTextBox.Text + " " +
                middleNameTextbox.Text + " " +
                lastNameTextbox.Text;
            // Display output string in the outputLabel
            nameOutputLabel.Text = output;
        }

        private void format2Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 2 button
            output = firstNameTextBox.Text + " " +
                middleNameTextbox.Text + " " +
                lastNameTextbox.Text;
            //Display output string in the outputLabel
            nameOutputLabel.Text = output;
        }

        private void format3Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 3 button
            output = firstNameTextBox.Text + " " +
                lastNameTextbox.Text;
            //Display output string in the outputLabel
            nameOutputLabel.Text = output;
        }

        private void format4Button_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 4 button
            output = lastNameTextbox.Text + "," + " " +
                firstNameTextBox.Text + " " +
                middleNameTextbox.Text + "," + " " +
                preferredNameTextbox.Text;
            //Display output string in the outputLabel
            nameOutputLabel.Text = output;

        }

        private void formatFiveButton_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 5 button
            output = lastNameTextbox.Text + "," + " " +
                firstNameTextBox.Text + " " +
                middleNameTextbox.Text;
            //Display output string in the outputLabel
            nameOutputLabel.Text = output;
        }

        private void formatSixButton_Click(object sender, EventArgs e)
        {
            //declare a string variable
            string output;

            //Concatenate the input and build output string for format 6 button
            output = lastNameTextbox.Text + "," + " " +
                firstNameTextBox.Text;
            //Display output string in the output label
            nameOutputLabel.Text = output;
        }
    }
}
