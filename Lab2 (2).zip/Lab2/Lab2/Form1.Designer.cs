﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextbox = new System.Windows.Forms.TextBox();
            this.lastNameTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.preferredNameTextbox = new System.Windows.Forms.TextBox();
            this.nameOutputLabel = new System.Windows.Forms.Label();
            this.formatOneButton = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format4Button = new System.Windows.Forms.Button();
            this.formatFiveButton = new System.Windows.Forms.Button();
            this.formatSixButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(223, 29);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(223, 77);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 1;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(223, 137);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(318, 26);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 3;
            // 
            // middleNameTextbox
            // 
            this.middleNameTextbox.Location = new System.Drawing.Point(318, 74);
            this.middleNameTextbox.Name = "middleNameTextbox";
            this.middleNameTextbox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextbox.TabIndex = 4;
            // 
            // lastNameTextbox
            // 
            this.lastNameTextbox.Location = new System.Drawing.Point(318, 130);
            this.lastNameTextbox.Name = "lastNameTextbox";
            this.lastNameTextbox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextbox.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(96, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Preferred Title (Mr., Mrs., Ms., Dr., etc.):";
            // 
            // preferredNameTextbox
            // 
            this.preferredNameTextbox.Location = new System.Drawing.Point(318, 178);
            this.preferredNameTextbox.Name = "preferredNameTextbox";
            this.preferredNameTextbox.Size = new System.Drawing.Size(100, 20);
            this.preferredNameTextbox.TabIndex = 7;
            // 
            // nameOutputLabel
            // 
            this.nameOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameOutputLabel.Location = new System.Drawing.Point(25, 228);
            this.nameOutputLabel.Name = "nameOutputLabel";
            this.nameOutputLabel.Size = new System.Drawing.Size(513, 45);
            this.nameOutputLabel.TabIndex = 8;
            // 
            // formatOneButton
            // 
            this.formatOneButton.Location = new System.Drawing.Point(25, 309);
            this.formatOneButton.Name = "formatOneButton";
            this.formatOneButton.Size = new System.Drawing.Size(75, 23);
            this.formatOneButton.TabIndex = 9;
            this.formatOneButton.Text = "Format 1";
            this.formatOneButton.UseVisualStyleBackColor = true;
            this.formatOneButton.Click += new System.EventHandler(this.formatOneButton_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(151, 309);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(75, 23);
            this.format2Button.TabIndex = 10;
            this.format2Button.Text = "Format 2";
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(306, 309);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(75, 23);
            this.format3Button.TabIndex = 11;
            this.format3Button.Text = "Format 3";
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format4Button
            // 
            this.format4Button.Location = new System.Drawing.Point(439, 309);
            this.format4Button.Name = "format4Button";
            this.format4Button.Size = new System.Drawing.Size(75, 23);
            this.format4Button.TabIndex = 12;
            this.format4Button.Text = "Format 4";
            this.format4Button.UseVisualStyleBackColor = true;
            this.format4Button.Click += new System.EventHandler(this.format4Button_Click);
            // 
            // formatFiveButton
            // 
            this.formatFiveButton.Location = new System.Drawing.Point(88, 360);
            this.formatFiveButton.Name = "formatFiveButton";
            this.formatFiveButton.Size = new System.Drawing.Size(75, 23);
            this.formatFiveButton.TabIndex = 13;
            this.formatFiveButton.Text = "Format 5";
            this.formatFiveButton.UseVisualStyleBackColor = true;
            this.formatFiveButton.Click += new System.EventHandler(this.formatFiveButton_Click);
            // 
            // formatSixButton
            // 
            this.formatSixButton.Location = new System.Drawing.Point(376, 360);
            this.formatSixButton.Name = "formatSixButton";
            this.formatSixButton.Size = new System.Drawing.Size(75, 23);
            this.formatSixButton.TabIndex = 14;
            this.formatSixButton.Text = "Format 6";
            this.formatSixButton.UseVisualStyleBackColor = true;
            this.formatSixButton.Click += new System.EventHandler(this.formatSixButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 411);
            this.Controls.Add(this.formatSixButton);
            this.Controls.Add(this.formatFiveButton);
            this.Controls.Add(this.format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.formatOneButton);
            this.Controls.Add(this.nameOutputLabel);
            this.Controls.Add(this.preferredNameTextbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lastNameTextbox);
            this.Controls.Add(this.middleNameTextbox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextbox;
        private System.Windows.Forms.TextBox lastNameTextbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox preferredNameTextbox;
        private System.Windows.Forms.Label nameOutputLabel;
        private System.Windows.Forms.Button formatOneButton;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format4Button;
        private System.Windows.Forms.Button formatFiveButton;
        private System.Windows.Forms.Button formatSixButton;
    }
}

