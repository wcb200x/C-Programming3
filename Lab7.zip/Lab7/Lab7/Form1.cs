﻿/*William Brown
 * CIS 199-75
 * LAb 7
 * 3/29/16
 * This program is designed to calculate a certain ticket price depending on how many miles are traveled. This program uses a while
 * loop and TryParse data validation for user input. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clickMeButton_Click(object sender, EventArgs e)
            //Precondition: number of miles >=0
            //Postcondition: assign total ticket price to output
        {
            double numMilesTraveled; // variable to hold user input for miles 

            //validating user input as an integer and assigning it to a variable
            if (double.TryParse(milesTextbox.Text, out numMilesTraveled)) 
            {
                double[] distanceTraveled = { 0, 100, 300, 500 }; // array for amount of miles traveled

                double[] priceRate = { 25.00, 40.00, 55.00, 70.00 }; // array for the price of the tickets

                double ticketPrice; // variable to hold the price of the ticket based on user input

                int index = distanceTraveled.Length - 1; // assigning variable index a value

                // loop setting conditions to determine price based on user input
                while (index >= 0 && numMilesTraveled < distanceTraveled[index]) --index;

                ticketPrice = priceRate[index]; // assigning a value to variable ticketPrice

                outputLabel.Text = ticketPrice.ToString("c"); // setting the outputLabel to display ticketPrice
            }
        }
    }
}
